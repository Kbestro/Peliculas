import sys
import re
import json
import urllib.request
import urllib.parse
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
GITHUB_API = "https://api.github.com/repos/Kbestro/Peliculas/contents/"
TMDB_KEY = "f090bb54758cabf231fb605d3e3e0468"

def limpiar_titulo(nombre):
    sin_ext = re.sub(r'\.strm$', '', nombre, flags=re.IGNORECASE)
    anio_match = re.search(r'\((\d{4})\)', sin_ext)
    anio = anio_match.group(1) if anio_match else ""
    limpio = re.sub(r'[\(\[\{].*?[\)\]\}]', '', sin_ext)
    limpio = re.split(r'\b(1080p|720p|2160p|4K|HDR|BluRay|WEBRip|WEB-DL|DVDRip|x264|x265|HEVC|CASTELLANO|ESP|LATINO)\b', limpio, flags=re.IGNORECASE)[0]
    limpio = re.sub(r'[\\/*?:"<>|]', '', limpio.replace('.', ' ').replace('_', ' ')).strip(" -")
    return (limpio or sin_ext), anio

def buscar_tmdb(titulo, anio):
    try:
        q = urllib.parse.quote(titulo)
        url = f"https://api.themoviedb.org/3/search/movie?api_key={TMDB_KEY}&language=es-ES&query={q}"
        if anio:
            url += f"&year={anio}"
        req = urllib.request.Request(url, headers={"User-Agent": "KodiAddon"})
        with urllib.request.urlopen(req, timeout=4) as r:
            res = json.loads(r.read().decode("utf-8")).get("results", [])
            if res:
                m = res[0]
                poster = f"https://image.tmdb.org/t/p/w500{m['poster_path']}" if m.get("poster_path") else ""
                fanart = f"https://image.tmdb.org/t/p/w1280{m['backdrop_path']}" if m.get("backdrop_path") else ""
                return m.get("title", titulo), m.get("overview", "Sin sinopsis disponible."), poster, fanart, m.get("vote_average", 0)
    except Exception:
        pass
    return titulo, "", "", "", 0

def listar_peliculas():
    xbmcplugin.setContent(HANDLE, "movies")
    req = urllib.request.Request(GITHUB_API, headers={"User-Agent": "KodiAddon"})
    with urllib.request.urlopen(req, timeout=8) as resp:
        archivos = json.loads(resp.read().decode("utf-8"))

    for item in archivos:
        nombre = item.get("name", "")
        if not nombre.lower().endswith(".strm"):
            continue
        raw_url = item.get("download_url", "")
        titulo_limpio, anio = limpiar_titulo(nombre)
        titulo_oficial, sinopsis, poster, fanart, nota = buscar_tmdb(titulo_limpio, anio)

        li = xbmcgui.ListItem(label=titulo_oficial)
        info = {"title": titulo_oficial, "plot": sinopsis, "mediatype": "movie"}
        if anio.isdigit():
            info["year"] = int(anio)
        if nota:
            info["rating"] = float(nota)
        li.setInfo("video", info)
        if poster or fanart:
            li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        li.setProperty("IsPlayable", "true")

        # Leemos el enlace magnet/elementum del .strm
        try:
            with urllib.request.urlopen(raw_url, timeout=4) as f_strm:
                play_url = f_strm.read().decode("utf-8").strip()
        except Exception:
            continue

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

listar_peliculas()